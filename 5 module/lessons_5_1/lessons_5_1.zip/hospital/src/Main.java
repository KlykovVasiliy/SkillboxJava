import java.math.BigDecimal;
import java.math.RoundingMode;

public class Main {
    public static double round(double value, int place) {
        BigDecimal individTempr = new BigDecimal(Double.toString(value));
        individTempr = individTempr.setScale(place, RoundingMode.HALF_UP);
        return individTempr.doubleValue();
    }

    public static void main(String[] args) {
        double[] temperature = new double[30];
        double sumTempr = 0.0;
        double minTempr = 32.0;
        double maxTempr = 40.0;
        int goodPatiintCount = 0;
        maxTempr -= minTempr;

        for (int i = 0; i < temperature.length; i++) {
            temperature[i] = minTempr + (Math.random() * maxTempr);
            temperature[i] = round(temperature[i], 1);
            sumTempr += temperature[i];
            System.out.print("Температура " + (i + 1) + "го " + "пациента ");
            System.out.println(temperature[i] + " градусов.");

            if (temperature[i] > 36.2 && temperature[i] < 36.9) {
                goodPatiintCount++;
            }
        }

        System.out.println();
        double midlleTempr = round(sumTempr / temperature.length, 1);
        System.out.println("Средняя температура пациентов " +
                "по больнице " + midlleTempr + " градусов Цельсия.");
        System.out.println();
        System.out.println("Количество здоровых пациентов " + goodPatiintCount);
    }
}