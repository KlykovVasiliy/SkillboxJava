public class Container
{
    public Integer count = 0;
}